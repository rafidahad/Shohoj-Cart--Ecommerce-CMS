export const cn = (...inputs) => {
    return inputs.filter(Boolean).join(" ");
  };
  