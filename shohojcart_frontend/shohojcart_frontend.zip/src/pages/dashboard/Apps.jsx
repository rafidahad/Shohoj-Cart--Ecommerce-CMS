import React from "react";

export default function Apps() {
    return (
        <>
            <h1 className="text-3xl font-extrabold mb-6 text-gray-800">Apps</h1>
            <div className="bg-white rounded-2xl p-8 shadow-xl border border-gray-100">
                <p className="text-gray-600 text-lg">This is the Apps page. Manage your apps here.</p>
            </div>
        </>
    );
}
